<?php

namespace Vdcstore\NewsletterPopup\Block;

class Subscribe extends \Magento\Framework\View\Element\Template
{
    protected $_storeManager;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Vdcstore\NewsletterPopup\Model\Cookie           $Cookie,
        \Vdcstore\NewsletterPopup\Helper\Data            $helperdata,
        \Magento\Store\Model\StoreManagerInterface       $storeManager,
        array                                            $data = []
    )
    {
        parent::__construct($context, $data);
        $this->_storeManager = $storeManager;
        $this->Cookie = $Cookie;
        $this->helperdata = $helperdata;

    }

    public function getFormActionUrl()
    {
        return $this->getUrl('subscribe/index/popup', ['_secure' => true]);
    }

    public function getCustomCookie()
    {
        return $this->Cookie->getCustomCookie();
    }

    public function getEnabl()
    {
        return $this->helperdata->getGeneralConfig('enable');
    }

    public function getButtonTitle()
    {
        return $this->helperdata->getGeneralConfig('button_title');
    }

    public function getPopupTitle()
    {
        return $this->helperdata->getGeneralConfig('popup_title');
    }

    public function getPopupHeight()
    {
        return $this->helperdata->getGeneralConfig('popup_height');
    }

    public function getPopupWidth()
    {
        return $this->helperdata->getGeneralConfig('popup_width');
    }

    public function getBackgroundColor()
    {
        return $this->helperdata->getGeneralConfig('background_color');
    }

    public function getButtonColor()
    {
        return $this->helperdata->getGeneralConfig('button_color');
    }

    public function getImage()
    {
        $baseurl = $this->_storeManager->getStore()->getBaseUrl();


        $imageupload = $this->helperdata->getGeneralConfig('image_upload');

        return $baseurl . 'media/' . 'blog/' . 'post/' . $imageupload;
    }

}
